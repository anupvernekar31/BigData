# Big-Data-Lab

7th Semester Big Data Lab Programs & Installation files.

## Topics Covered

- Hadoop Mapreduce

- Pig

- Spark & Scala

- Hive

- HBase
