## Step to run installation script

`bash ./hadoop-install.sh`
