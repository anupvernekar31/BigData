## Step to run installation script

- Extract xmlfiles.zip and save all the individual xml files to Downloads folder.

- run `bash install-hive.sh` in the terminal

## Important Note

- Internet connection is required.

- This script will download Hadoop and Hive to the Downloads folder.

- Variables like $HADOOP_HOME & $HIVE_HOME are set globally in the ~/.bashrc file.
