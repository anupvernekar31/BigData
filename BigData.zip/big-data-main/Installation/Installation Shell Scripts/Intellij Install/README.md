# Install IntelliJ

A shell script to automate the installation of IntelliJ (Community Version)

## Step to run installation script

`bash ./hadoop-install.sh`
